
Start the development server with
```
yarn
yarn dev
```
