import os

os.system("pip install --upgrade --quiet langchain-core")

os.system("pip install --upgrade --quiet langchain langchainhub")

os.system("pip install -qU langchain-openai")

os.system("pip install pandas")

