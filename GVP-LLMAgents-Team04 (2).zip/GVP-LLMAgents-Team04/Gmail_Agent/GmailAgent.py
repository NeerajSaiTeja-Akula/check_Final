from langchain_core.tools import tool
import os
from email.message import EmailMessage
import ssl
import smtplib
import pandas as pd
from langchain import hub
import getpass
import os
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent


@tool
def email_retriever(query: str) -> list():
    """Email retriver retrives emails from excel sheet and returns the list of emails of selected candidates. returns list(str): emails_list"""
    emails_list=[]
    a=pd.read_csv("data.csv")
    for i in range(0,int(a.count())):
      emails_list+=list(a.loc[i])
    return emails_list

@tool
def compose_email(job_title: str, company_name: str) -> list():
  """
  Composes a professional email congratulating a candidate on being selected for a Software Engineer position.

  Args:
      job_title (str): The specific Software Engineer position title.
      company_name (str): The company name.

  Returns:
      list: list of subject and body.
  """

  subject = f"Congratulations! You've been selected for the {job_title} position at {company_name}."

  body = f"""\
    Dear Candidate,

    We are thrilled to inform you that you have been selected for the Job at Acme Inc. !

    Your skills and experience during the interview process truly impressed us. We were particularly impressed by [mention specific skills or experiences that stood out]. We believe you will be a valuable asset to our team and are confident that you will make significant contributions to {company_name}.

    In the coming days, you will receive a formal offer letter outlining the details of the position, including compensation and benefits.

    In the meantime, if you have any questions, please do not hesitate to contact us. We look forward to welcoming you to the team!

    Sincerely,

    {company_name}  Hiring Team
    """

  return [subject, body]

@tool
def send_email(email_sender: str,email_reciver: str,subject:str ,body:str)->None:
    """[dependencies get data from generate_subject_and_body_for_email ]sends email to email_reciver from email_sender email_sender.Args:email_sender (str):specifies email of sender if not provided default is neerajsaiteja@gmail.com,email_reciver (str):specifies email of reciver if not provided default is jackmaxak@gmail.com,subject (str):subject of the mail if not provided default is None,body (str): body of the mail if not provided default if empty. Returns:(str)"""
    email_password="woef glei rhlf arjy"
    em=EmailMessage()
    em['From']=email_sender
    em['To']=email_reciver
    em['Subject']=subject
    em.set_content(body)

    context=ssl.create_default_context()
    print(em.as_string())
    with smtplib.SMTP_SSL('smtp.gmail.com',465,context=context) as smtp:
        print("hi")
        smtp.login(email_sender,email_password)
        print("hello")
        smtp.sendmail(email_sender,email_reciver,em.as_string())

prompt = hub.pull("hwchase17/openai-tools-agent")
prompt.pretty_print()

os.environ["OPENAI_API_KEY"] = getpass.getpass()


llm = ChatOpenAI(model="gpt-3.5-turbo-0125")
tools = [send_email,email_retriever]
# Construct the tool calling agent
agent = create_tool_calling_agent(llm, tools, prompt)
# Create an agent executor by passing in the agent and tools
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

agent_executor.invoke(
    {
        "input": "generate subject and body and send send mail to 322103310003@gvpce.ac.in from neerajsaiteja@gmail.com regarding his selection as S.D.E at Alchamy.inc"
    }
)

agent_executor.invoke(
    {
        "input": "compose and send mail to all mails in data from neerajsaiteja@gmail.com regarding his selection as S.D.E at Alchamy.inc"
    }
)