# Gemini Voice Assistant
## Setup

1. Clone the repository.
2. Install the required packages:
    ```bash
    pip install -r requirements.txt
    ```
## Running the Assistant

Run the assistant using the following command:
```bash
python main.py
