npm install
yarn
yarn dev